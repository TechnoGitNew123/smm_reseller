<!DOCTYPE html>

<html>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header pt-0 pb-2">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-left mt-2">
            <h4>Package Payment</h4>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <section class="default-page mt-5 mb-5">
              <div class="container">
                <div class="row">
                  <div class="col-md-12 text center">
                    <h1 class="page-heading">Payment Success</h1>
                  </div>
                  <div class="col-md-12">
                    <div class="card p-5">
                      <h4 class="text-success">Order Placed Successfully</h4>
                      <h4 class="text-success">Payment Successfull</h4>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </section>
  </div>
</body>
</html>
