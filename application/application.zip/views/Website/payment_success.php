  <?php include('include/head1.php') ?>
    <div class="top_strip"></div>

    <section class="default-page mt-5 mb-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text center">
            <h1 class="page-heading">Payment Success</h1>
          </div>
          <div class="col-md-12">
            <div class="card p-5">
              <h4 class="text-success">Order Placed Successfully</h4>
              <h4 class="text-success">Payment Successfull</h4>
            </div>
          </div>
        </div>
      </div>
    </section>

    <?php include('include/footer1.php') ?>
  </body>
</html>
